document.getElementById('btn').addEventListener('click', () => {
    const tokenInput = document.getElementById('token');
  const token = tokenInput.value;

  chrome.runtime.sendMessage({ token: token });
  });
